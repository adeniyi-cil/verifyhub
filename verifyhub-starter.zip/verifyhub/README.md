# VerifyHub — Pi Network App Starter

## Files in this folder
- `index.html` — Your entire app (front-end)
- `vercel.json` — Vercel deployment config
- `public/validation-key.txt` — Pi domain ownership file (fill in your key)

---

## How to Deploy to Vercel (10 minutes)

### Step 1 — Create a GitHub account
Go to https://github.com and sign up (free).

### Step 2 — Create a new repository
- Click "New repository"
- Name it: `verifyhub`
- Set to Public
- Click "Create repository"

### Step 3 — Upload your files
- Click "uploading an existing file"
- Upload: `index.html`, `vercel.json`, and the `public/` folder

### Step 4 — Deploy to Vercel
- Go to https://vercel.com and sign up with GitHub
- Click "New Project"
- Import your `verifyhub` repository
- Click Deploy (no settings needed to change)
- Vercel gives you a URL like: `https://verifyhub.vercel.app`

### Step 5 — Fill in Pi Developer Portal
Paste your Vercel URL into:
- "Your App's URL" field in Pi Dev Portal

---

## Pi Validation Key
When Pi gives you a validation key in the portal:
1. Open `public/validation-key.txt`
2. Replace `PASTE_YOUR_PI_VALIDATION_KEY_HERE` with your actual key
3. Re-upload to GitHub → Vercel auto-redeploys
4. Pi will verify your domain ownership

---

## Going to Mainnet
When you're ready to go live:
1. In `index.html`, find this line:
   ```
   const SANDBOX = true;
   ```
2. Change it to:
   ```
   const SANDBOX = false;
   ```
3. Push to GitHub → auto-redeploys

---

## What's Needed Next (Backend)
The payment flow requires a small backend server to:
- Approve payments (onReadyForServerApproval)
- Complete payments (onReadyForServerCompletion)
Pi requires server-side verification for security.
A simple Node.js/Express backend on Vercel handles this.
